package my.edu.tarc.user.fyp.Model;

public class Products {
    private String pID;
    private String pDescription;
    private String pImageUri;
    private String pName;
    private double pSellPrice;

    public Products(){

    }

    public Products(String pID, String pDescription, String pImageUri, String pName, double pSellPrice) {
        this.pID = pID;
        this.pDescription = pDescription;
        this.pImageUri = pImageUri;
        this.pName = pName;
        this.pSellPrice = pSellPrice;
    }

    public String getpID() {
        return pID;
    }

    public void setpID(String pID) {
        this.pID = pID;
    }

    public String getpDescription() {
        return pDescription;
    }

    public void setpDescription(String pDescription) {
        this.pDescription = pDescription;
    }

    public String getpImageUri() {
        return pImageUri;
    }

    public void setpImageUri(String pImageUri) {
        this.pImageUri = pImageUri;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public double getpSellPrice() {
        return pSellPrice;
    }

    public void setpSellPrice(double pSellPrice) {
        this.pSellPrice = pSellPrice;
    }
}

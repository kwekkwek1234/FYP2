package my.edu.tarc.user.fyp.ViewHolder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import my.edu.tarc.user.fyp.Interface.ItemClickListener;
import my.edu.tarc.user.fyp.R;

public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    public TextView pName, pPrice;
    public ImageView pImage;
    public ItemClickListener listener;

    public ProductViewHolder(@NonNull View itemView) {
        super(itemView);
        pImage = itemView.findViewById(R.id.productImage);
        pName = itemView.findViewById(R.id.productName);
        pPrice = itemView.findViewById(R.id.productPrice);
    }

    public void setItemClickListener(ItemClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View view) {
        listener.onClick(view, getAdapterPosition(), false);
    }
}
